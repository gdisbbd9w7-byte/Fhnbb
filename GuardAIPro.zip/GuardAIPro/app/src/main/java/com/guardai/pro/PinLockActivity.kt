package com.guardai.pro

import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class PinLockActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_SETUP = "setup"
        const val MODE_VERIFY = "verify"
        private const val PREF = "guard_pin"
        private const val KEY_PIN = "pin"

        fun isPinSet(ctx: Context): Boolean =
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).contains(KEY_PIN)

        fun verifyPin(ctx: Context, pin: String): Boolean =
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getString(KEY_PIN, null) == pin
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_SETUP

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        val label = TextView(this).apply {
            text = if (mode == MODE_SETUP) "Set 4-digit PIN" else "Enter PIN"
            textSize = 22f
        }
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "PIN"
        }
        val btn = Button(this).apply {
            text = if (mode == MODE_SETUP) "Save" else "Verify"
        }
        btn.setOnClickListener {
            val pin = input.text.toString()
            if (pin.length != 4) {
                Toast.makeText(this, "PIN must be 4 digits", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val prefs = getSharedPreferences(PREF, Context.MODE_PRIVATE)
            if (mode == MODE_SETUP) {
                prefs.edit().putString(KEY_PIN, pin).apply()
                Toast.makeText(this, "PIN saved", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                if (prefs.getString(KEY_PIN, null) == pin) {
                    setResult(RESULT_OK); finish()
                } else {
                    Toast.makeText(this, "Wrong PIN", Toast.LENGTH_SHORT).show()
                }
            }
        }
        root.addView(label); root.addView(input); root.addView(btn)
        setContentView(root)
    }
}
