package com.guardai.pro

import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object BlockListManager {

    private const val PREF = "guard_blocklist"
    private const val KEY_KEYWORDS = "keywords"
    private const val REMOTE_URL = "https://example.com/guardai/blocklist.json"

    private val DEFAULT_KEYWORDS = setOf(
        "porn", "xxx", "adult", "sex", "nude", "nsfw", "hentai", "erotic"
    )

    fun getKeywords(ctx: Context): Set<String> {
        val prefs = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val saved = prefs.getStringSet(KEY_KEYWORDS, null)
        return saved ?: DEFAULT_KEYWORDS
    }

    fun refreshFromRemote(ctx: Context) {
        try {
            val conn = URL(REMOTE_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 5000
            conn.readTimeout = 5000
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val arr = json.optJSONArray("keywords") ?: return
                val set = mutableSetOf<String>()
                for (i in 0 until arr.length()) set.add(arr.getString(i).lowercase())
                if (set.isNotEmpty()) {
                    ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                        .edit().putStringSet(KEY_KEYWORDS, set).apply()
                }
            }
        } catch (t: Throwable) {
            Log.w("GuardAI-Blocklist", "remote refresh failed: ${t.message}")
        }
    }
}
