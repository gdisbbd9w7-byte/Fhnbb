package com.guardai.pro

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MyAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "GuardAI-A11y"
        private const val DEBOUNCE_MS = 4000L
    }

    private var lastTrigger = 0L

    private val browserPackages = setOf(
        "com.android.chrome",
        "com.chrome.beta",
        "com.opera.browser",
        "com.opera.mini.native",
        "org.mozilla.firefox",
        "com.microsoft.emmx",
        "com.brave.browser",
        "com.sec.android.app.sbrowser",
        "com.UCMobile.intl",
        "com.duckduckgo.mobile.android"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        try {
            val texts = mutableListOf<String>()
            event.text?.forEach { texts.add(it.toString()) }
            rootInActiveWindow?.let { collectText(it, texts, 0) }

            val haystack = texts.joinToString(" ").lowercase()
            if (haystack.isBlank()) return

            val keywords = BlockListManager.getKeywords(this)
            val matched = keywords.firstOrNull { haystack.contains(it) }
            if (matched != null) {
                val isBrowser = pkg in browserPackages
                Log.d(TAG, "Match='$matched' pkg=$pkg browser=$isBrowser")
                triggerBlock(matched)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "event error", t)
        }
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 8) return
        node.text?.let { out.add(it.toString()) }
        node.contentDescription?.let { out.add(it.toString()) }
        for (i in 0 until node.childCount) {
            collectText(node.getChild(i), out, depth + 1)
        }
    }

    private fun triggerBlock(reason: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastTrigger < DEBOUNCE_MS) return
        lastTrigger = now

        // Try to navigate away
        performGlobalAction(GLOBAL_ACTION_HOME)

        val i = Intent(this, WarningActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP or
                Intent.FLAG_ACTIVITY_NO_HISTORY
            )
            putExtra("reason", reason)
        }
        startActivity(i)
    }

    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i(TAG, "Accessibility connected")
    }
}
