package com.guardai.pro

import android.graphics.Bitmap

/**
 * Lightweight NSFW detection stub.
 * Replace `analyze()` with a real model (e.g., TensorFlow Lite NSFW model)
 * or an HTTP moderation API call.
 */
object NsfwDetector {
    data class Result(val isNsfw: Boolean, val score: Float)

    fun analyze(bitmap: Bitmap): Result {
        // Simple heuristic placeholder: skin-tone pixel ratio.
        val w = bitmap.width; val h = bitmap.height
        val sample = 32
        var skin = 0; var total = 0
        for (y in 0 until h step (h / sample).coerceAtLeast(1)) {
            for (x in 0 until w step (w / sample).coerceAtLeast(1)) {
                val c = bitmap.getPixel(x, y)
                val r = (c shr 16) and 0xff
                val g = (c shr 8) and 0xff
                val b = c and 0xff
                if (r > 95 && g > 40 && b > 20 && r > g && r > b && (r - g) > 15) skin++
                total++
            }
        }
        val ratio = if (total == 0) 0f else skin.toFloat() / total
        return Result(ratio > 0.45f, ratio)
    }
}
