package com.guardai.pro

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        val title = TextView(this).apply {
            text = "Guard AI Pro"
            textSize = 28f
            setPadding(0, 0, 0, 24)
        }

        val status = TextView(this).apply {
            text = "Tap each step to enable protection."
            textSize = 16f
            setPadding(0, 0, 0, 32)
        }

        val btnAccessibility = Button(this).apply {
            text = "1. Enable Accessibility Service"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val btnOverlay = Button(this).apply {
            text = "2. Grant Overlay Permission"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                    !Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                }
            }
        }

        val btnPin = Button(this).apply {
            text = "3. Set / Change PIN"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, PinLockActivity::class.java)
                    .putExtra(PinLockActivity.EXTRA_MODE, PinLockActivity.MODE_SETUP))
            }
        }

        val btnStart = Button(this).apply {
            text = "4. Start Protection Service"
            setOnClickListener {
                val intent = Intent(this@MainActivity, MyForegroundService::class.java)
                ContextCompat.startForegroundService(this@MainActivity, intent)
                status.text = "Guard AI is now protecting you."
            }
        }

        root.addView(title)
        root.addView(status)
        root.addView(btnAccessibility)
        root.addView(btnOverlay)
        root.addView(btnPin)
        root.addView(btnStart)
        setContentView(root)
    }
}
